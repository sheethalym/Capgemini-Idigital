export interface Office {
    id: number,
    documentType: string,
    endDate: Date
}
